import './footer.css'


function Footer()
{
    return (
        <div className="footSection">
            <h5>A great place to be! <em>2021</em></h5>
            <h6>Julian Smith</h6>
        </div>
    );
}

export default Footer;