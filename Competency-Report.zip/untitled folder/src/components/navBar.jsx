import './navBar.css';

import { Link } from 'react-router-dom';
import { useContext } from 'react/cjs/react.development';
import StoreContext from '../context/store-context';


function NavBar() 
{
  const cart = useContext(StoreContext).cart;

    return (
      <nav className="navbar navbar-dark bg-dark">
        <div className="container-fluid">
          <Link className="nav-link" to="/"><a className="navbar-brand">Pen Pro</a></Link>
          <Link className="nav-link" to="/Catalog">Catalog</Link>
          <Link className="nav-link" to="/About">About</Link>
          <form className="d-flex">
            <Link className="btn btn-outline-light" to="/cart">
              <span className="badge bg-primary me-2">{cart.length}</span>
              View Cart
            </Link>
          </form>
        </div>
      </nav>
    );
}

export default NavBar;