import './about.css'

const About = () => {
    return(
        <div>
            <h1>About me:</h1>
            <h5>Jimmy Newtron</h5>
            <hr />
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quasi expedita praesentium voluptatibus dolore sapiente aliquid odit officiis illo esse pariatur, cupiditate nobis! Nesciunt neque, nulla placeat consectetur ratione ducimus rem.</p>
        </div>
    )
}

export default About;