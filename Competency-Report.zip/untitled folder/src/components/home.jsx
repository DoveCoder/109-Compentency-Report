import './home.css';


const Home = () => {
    return(
        <div>
            <div className="home-background">
                <h1 className="home-h1">This is Pen Pro for professionals.</h1>
            </div>
        </div>
    )
    
}

export default Home;